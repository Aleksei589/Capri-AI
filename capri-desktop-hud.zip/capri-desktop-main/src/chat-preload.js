'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('chat', {
  state: () => ipcRenderer.invoke('chat:state'),
  send: (payload) => ipcRenderer.invoke('chat:send', {
    text: String(payload?.text || ''),
    files: (payload?.files || []).map((f) => ({ name: String(f.name), mime: String(f.mime || ''), data: f.data })),
  }),
  list: () => ipcRenderer.invoke('chat:list'),
  open: (id) => ipcRenderer.invoke('chat:open', String(id)),
  create: () => ipcRenderer.invoke('chat:new'),
  remove: (id) => ipcRenderer.invoke('chat:delete', String(id)),
  file: (id, file) => ipcRenderer.invoke('chat:file', String(id), String(file)),
  setKey: (key) => ipcRenderer.invoke('chat:setKey', String(key)),
  clearKey: () => ipcRenderer.invoke('chat:clearKey'),
  onChanged: (fn) => ipcRenderer.on('chat:changed', () => fn()),
  keyPage: () => ipcRenderer.send('chat:keyPage'),
});
