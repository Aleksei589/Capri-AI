'use strict';

const path = require('node:path');
const fs = require('node:fs');
const { pathToFileURL } = require('node:url');
const {
  app, BrowserWindow, Tray, Menu, ipcMain, screen, protocol, net, shell, globalShortcut, nativeImage, clipboard,
} = require('electron');

const config = require('./config');
const { TRAY, LANGS } = require('./labels');
const { createBridge } = require('./bridge');
const { startWindowWatch } = require('./windows');
const chat = require('./chat');
const { startMedia } = require('./media');
const hooks = require('../../scripts/install-hooks');
const demoSteps = require('../../scripts/demo-sequence');

const ROOT = path.resolve(__dirname, '..', '..');
const DEV = process.argv.includes('--dev');
const PORT = Number(process.env.CAPRI_PORT) || 47823;
const SOUND_EXT = /\.(mp3|wav|ogg|m4a)$/i;
const CLAUDE_CODE_HELP = 'https://code.claude.com/docs/en/quickstart';

protocol.registerSchemesAsPrivileged([
  { scheme: 'capri', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true } },
]);

let overlay = null;
let chatWin = null;
let quickWin = null;     // the one-line bar she is talked to through
let quickBusy = false;
let quickWait = null;
let tray = null;
let trayMenu = null; // also what she opens when you right-click her
let demoTimer = null;
let windowWatch = null;
let media = null;
// the watcher only speaks when something changes: the overlay asks for this when it (re)loads
let lastWindows = null;

const userSoundsDir = () => path.join(app.getPath('userData'), 'sounds');

// capri://app/...        -> files of this repo
// capri://usersounds/... -> the user's own sound overrides
function serveProtocol() {
  protocol.handle('capri', (request) => {
    const url = new URL(request.url);
    const base = url.host === 'usersounds' ? userSoundsDir() : ROOT;
    const target = path.resolve(base, '.' + decodeURIComponent(url.pathname));
    if (target !== base && !target.startsWith(base + path.sep)) {
      return new Response('forbidden', { status: 403 });
    }
    return net.fetch(pathToFileURL(target).toString());
  });
}

function targetDisplay() {
  const { displayId } = config.load();
  return screen.getAllDisplays().find((d) => d.id === displayId) || screen.getPrimaryDisplay();
}

function fitOverlay() {
  if (!overlay) return;
  const { workArea } = targetDisplay();
  overlay.setBounds(workArea);
  overlay.webContents.send('overlay:resize', { width: workArea.width, height: workArea.height });
}

function createOverlay() {
  const { workArea } = targetDisplay();
  overlay = new BrowserWindow({
    ...workArea,
    transparent: true,
    backgroundColor: '#00000000',
    frame: false,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    focusable: false,
    hasShadow: false,
    alwaysOnTop: true,
    type: process.platform === 'win32' ? 'toolbar' : undefined,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, '..', 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      backgroundThrottling: false,
      autoplayPolicy: 'no-user-gesture-required',
    },
  });

  overlay.setAlwaysOnTop(true, 'screen-saver');
  overlay.setIgnoreMouseEvents(true, { forward: true });
  overlay.loadURL('capri://app/src/renderer/index.html');
  // always shown: put away, she's still there as her biochip in the corner
  overlay.once('ready-to-show', () => overlay.showInactive());
  overlay.webContents.on('render-process-gone', (_e, details) => {
    console.error('[capri] renderer gone:', details.reason);
  });
  if (DEV) {
    overlay.webContents.on('console-message', (e) => {
      const { level, message, lineNumber, sourceId } = e;
      console.log(`[renderer:${level}] ${message} (${String(sourceId).split('/').pop()}:${lineNumber})`);
    });
    if (process.env.CAPRI_DEVTOOLS) overlay.webContents.openDevTools({ mode: 'detach' });
  }
}

function sendCommand(name, payload = {}) {
  overlay?.webContents.send('capri:command', { name, ...payload });
}

// Ctrl+Alt+V / tray: the chat window (Gemini). A normal focusable window, the overlay can't take typing.
function openChat() {
  if (chatWin && !chatWin.isDestroyed()) {
    if (chatWin.isMinimized()) chatWin.restore();
    chatWin.show();
    chatWin.focus();
    return;
  }
  chatWin = new BrowserWindow({
    width: 460,
    height: 780,
    minWidth: 360,
    minHeight: 560,
    title: 'Capri',
    backgroundColor: '#050b16',
    autoHideMenuBar: true,
    icon: path.join(ROOT, 'assets', 'icons', 'capri.png'),
    webPreferences: {
      preload: path.join(__dirname, '..', 'chat-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  chatWin.setMenu(null);
  chatWin.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  chatWin.webContents.on('will-navigate', (e) => e.preventDefault());
  chatWin.on('closed', () => { chatWin = null; });
  chatWin.loadURL('capri://app/src/renderer/chat.html');
}

const fromChat = (e) => Boolean(chatWin && !chatWin.isDestroyed() && e.sender === chatWin.webContents);
const chatFailure = (err) => ({ ok: false, code: err.code || 'other', message: err.message });

// One message to Capri, from the chat window or the quick bar: she notices, Gemini answers,
// and she makes the face, does the action and (when asked to) says it on screen.
async function answerChat(payload, { say }) {
  const text = String(payload?.text || '').slice(0, 4000);
  sendCommand('chatSend');
  const { reply, mood, action, id } = await chat.ask({ text, files: payload?.files });
  sendCommand('chat', { text: reply, mood, action, say });
  // putting herself away / coming back is a setting, so it goes through here
  if (action === 'hide' && config.load().visible) toggleVisible(false);
  else if (action === 'show' && !config.load().visible) toggleVisible(true);
  return { ok: true, reply, mood, action, id };
}

// ---------------------------------------------------------------- the quick bar

const QUICK_W = 460;
const QUICK_H = 92;

function createQuick() {
  quickWin = new BrowserWindow({
    width: QUICK_W,
    height: QUICK_H,
    show: false,
    frame: false,
    resizable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    title: 'Capri',
    backgroundColor: '#14101c',
    webPreferences: {
      preload: path.join(__dirname, '..', 'quick-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  quickWin.setAlwaysOnTop(true, 'screen-saver');
  quickWin.setMenu(null);
  quickWin.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  quickWin.webContents.on('will-navigate', (e) => e.preventDefault());
  // click somewhere else and it goes away (unless she is still answering: then once she has)
  quickWin.on('blur', () => { if (!quickBusy) quickWin?.hide(); });
  quickWin.on('closed', () => { quickWin = null; });
  quickWin.loadURL('capri://app/src/renderer/quick.html');
}

// `at`: where her head is on the overlay (css px), so the bar sits just above her.
function showQuick(at) {
  if (!quickWin || quickWin.isDestroyed()) createQuick();
  const b = overlay.getBounds();
  const point = at && Number.isFinite(at.x) && Number.isFinite(at.y)
    ? { x: Math.round(b.x + at.x), y: Math.round(b.y + at.y) }
    : { x: Math.round(b.x + b.width / 2), y: Math.round(b.y + b.height - 40) };
  const wa = screen.getDisplayNearestPoint(point).workArea;
  const x = Math.min(Math.max(point.x - QUICK_W / 2, wa.x + 8), wa.x + wa.width - QUICK_W - 8);
  const y = Math.min(Math.max(point.y - QUICK_H - 12, wa.y + 8), wa.y + wa.height - QUICK_H - 8);
  quickWin.setBounds({ x, y, width: QUICK_W, height: QUICK_H });
  quickWin.show();
  quickWin.focus();
  quickWin.webContents.send('quick:show');
}

// Hotkey / tray: ask the overlay where she is, then show the bar there (or low in the middle if it doesn't answer).
// Ctrl+Alt+T: she translates what you copied, into her interface language (or English if it's already that).
async function translateClipboard() {
  const text = clipboard.readText().trim();
  if (!text) return sendCommand('translate', { error: 'empty' });
  sendCommand('translate', { busy: true });
  try {
    const out = await chat.translate(text, resolveLang(config.load().lang));
    const names = (code) => {
      try {
        const name = new Intl.DisplayNames([resolveLang(config.load().lang)], { type: 'language' }).of(code) || code;
        return name.charAt(0).toUpperCase() + name.slice(1);
      } catch {
        return code;
      }
    };
    sendCommand('translate', { ok: true, from: out.from ? names(out.from) : '', to: names(out.to), text: out.text });
  } catch (err) {
    sendCommand('translate', { error: err.code || 'other', message: err.message });
  }
}

function openQuick() {
  if (quickWin && !quickWin.isDestroyed() && quickWin.isVisible()) {
    quickWin.focus();
    return;
  }
  clearTimeout(quickWait);
  sendCommand('quickAt');
  quickWait = setTimeout(() => showQuick(null), 500);
}

const fromQuick = (e) => Boolean(quickWin && !quickWin.isDestroyed() && e.sender === quickWin.webContents);

function registerQuickIpc() {
  ipcMain.on('quick:at', (e, at) => {
    if (e.sender !== overlay?.webContents) return;
    clearTimeout(quickWait);
    showQuick(at);
  });
  ipcMain.handle('quick:state', (e) => {
    if (!fromQuick(e)) return null;
    return { lang: resolveLang(config.load().lang), hasKey: chat.hasKey() };
  });
  ipcMain.handle('quick:send', async (e, payload) => {
    if (!fromQuick(e)) return chatFailure(new Error('forbidden'));
    quickBusy = true;
    try {
      const result = await answerChat(payload, { say: true });
      chatWin?.webContents.send('chat:changed'); // an open chat window shows what was just said
      return result;
    } catch (err) {
      if (err.code === 'nokey' || err.code === 'badkey') openChat(); // the key is set up there
      return chatFailure(err);
    } finally {
      quickBusy = false;
      if (quickWin && !quickWin.isDestroyed() && !quickWin.isFocused()) quickWin.hide();
    }
  });
  ipcMain.on('quick:close', (e) => { if (fromQuick(e)) quickWin.hide(); });
}

function registerChatIpc() {
  // every handler answers only to the chat window
  const guarded = (name, fn) => ipcMain.handle(name, async (e, ...args) => {
    if (!fromChat(e)) return chatFailure(new Error('forbidden'));
    try {
      return await fn(...args);
    } catch (err) {
      return chatFailure(err);
    }
  });

  ipcMain.handle('chat:state', (e) => {
    if (!fromChat(e)) return null;
    return { ...chat.state(), lang: resolveLang(config.load().lang), accept: chat.ACCEPT };
  });
  guarded('chat:send', (payload) => answerChat(payload, { say: !chatWin?.isFocused() }));
  guarded('chat:list', () => ({ ok: true, list: chat.list() }));
  guarded('chat:open', (id) => ({ ok: true, conv: chat.open(String(id)) }));
  guarded('chat:new', () => ({ ok: true, conv: chat.create() }));
  guarded('chat:delete', (id) => ({ ok: true, conv: chat.remove(String(id)) }));
  guarded('chat:file', (id, file) => ({ ok: true, bytes: chat.fileBytes(String(id), String(file)) }));
  guarded('chat:setKey', async (key) => {
    await chat.setKey(key);
    return { ok: true };
  });
  ipcMain.handle('chat:clearKey', (e) => { if (fromChat(e)) chat.clearKey(); });
  ipcMain.on('chat:keyPage', (e) => {
    if (fromChat(e)) shell.openExternal('https://aistudio.google.com/apikey');
  });
}

// Ctrl+Alt+C: she folds herself away into her biochip in the corner, or comes back out of it.
function toggleVisible(force) {
  const visible = typeof force === 'boolean' ? force : !config.load().visible;
  config.save({ visible });
  sendCommand('stow', { on: !visible });
  rebuildTray();
}

function playDemo() {
  clearTimeout(demoTimer);
  let i = 0;
  const next = () => {
    if (i >= demoSteps.length) return;
    const [delay, evt] = demoSteps[i++];
    demoTimer = setTimeout(() => {
      overlay?.webContents.send('claude:event', evt);
      next();
    }, delay);
  };
  next();
}

// During the demo, a little fake terminal for her to sit on and take over (window tracking is
// Windows only, so only there). Opened without stealing focus; closing it drops her off it.
let demoWin = null;
const DEMO_TERMINAL = `<body style="margin:0;background:#14101c;color:#8f8aa3;font:13px/1.7 Consolas,monospace;padding:14px 18px">
<div style="color:#36ff7a">PS C:\\night-city-api&gt; npm test -- gigs</div>
<div>&nbsp;&nbsp;GET /gigs</div><div style="color:#36ff7a">&nbsp;&nbsp;&nbsp;&nbsp;✓ returns 20 items per page</div>
<div style="color:#36ff7a">&nbsp;&nbsp;&nbsp;&nbsp;✓ paginates with a cursor</div><div style="color:#36ff7a">&nbsp;&nbsp;&nbsp;&nbsp;✓ rejects a bad cursor</div>
<div>&nbsp;&nbsp;6 passing (212ms)</div><div style="color:#36ff7a">PS C:\\night-city-api&gt; _</div></body>`;

function demoWindow(open) {
  demoWin?.destroy();
  demoWin = null;
  if (!open || process.platform !== 'win32') return false;
  const b = overlay.getBounds();
  demoWin = new BrowserWindow({
    x: Math.round(b.x + b.width * 0.5 - 310), y: Math.round(b.y + b.height * 0.42), width: 620, height: 300,
    show: false, alwaysOnTop: true, title: 'night-city-api — npm test', backgroundColor: '#14101c', autoHideMenuBar: true,
  });
  demoWin.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(DEMO_TERMINAL)}`);
  demoWin.once('ready-to-show', () => demoWin?.showInactive());
  demoWin.on('closed', () => { demoWin = null; });
  return true;
}

// 'auto' -> the first system language Capri speaks, English otherwise.
function resolveLang(setting) {
  if (LANGS.includes(setting)) return setting;
  const preferred = [...app.getPreferredSystemLanguages(), app.getSystemLocale(), app.getLocale()];
  for (const tag of preferred) {
    const base = String(tag || '').toLowerCase().split(/[-_]/)[0];
    if (LANGS.includes(base)) return base;
  }
  return 'en';
}

// What the overlay gets: `lang` is the resolved one, `langSetting` what the user picked.
function rendererConfig() {
  const cfg = config.load();
  return { ...cfg, lang: resolveLang(cfg.lang), langSetting: cfg.lang };
}

function updateConfig(patch) {
  config.save(patch);
  const cfg = rendererConfig();
  overlay?.webContents.send('capri:config', cfg);
  rebuildTray();
  return cfg;
}

function rebuildTray() {
  if (!tray) return;
  const cfg = config.load();
  const hookState = hooks.status();
  const t = TRAY[resolveLang(cfg.lang)];

  const displays = screen.getAllDisplays();
  const current = targetDisplay().id;

  const menu = Menu.buildFromTemplate([
    { label: t.online(PORT), enabled: false },
    { type: 'separator' },
    { label: t.chat, accelerator: 'Ctrl+Alt+V', click: openChat },
    { label: t.quick, accelerator: 'Ctrl+Alt+Space', click: openQuick },
    { label: t.translate, accelerator: 'Ctrl+Alt+T', click: translateClipboard },
    { label: t.player, accelerator: 'Ctrl+Alt+M', click: () => sendCommand('mediaCard') },
    { label: t.teleport, click: () => sendCommand('teleport') },
    { label: t.satellite, click: () => sendCommand('satellite') },
    { label: t.demo, click: playDemo },
    { label: t.help, click: () => sendCommand('welcome') },
    { label: cfg.visible ? t.hide : t.show, accelerator: 'Ctrl+Alt+C', click: () => toggleVisible() },
    { type: 'separator' },
    {
      label: t.size,
      submenu: [[t.small, 0.45], [t.medium, 0.6], [t.large, 0.8]].map(([label, scale]) => ({
        label, type: 'radio', checked: Math.abs(cfg.scale - scale) < 0.01, click: () => updateConfig({ scale }),
      })),
    },
    {
      label: t.sound,
      submenu: [
        { label: t.mute, type: 'checkbox', checked: cfg.muted, click: (item) => updateConfig({ muted: item.checked }) },
        { type: 'separator' },
        {
          label: t.soundsDir,
          click: () => {
            fs.mkdirSync(userSoundsDir(), { recursive: true });
            shell.openPath(userSoundsDir());
          },
        },
      ],
    },
    {
      label: t.screen,
      enabled: displays.length > 1,
      submenu: displays.map((d, i) => ({
        label: `${i + 1} — ${d.size.width}×${d.size.height}`,
        type: 'radio',
        checked: d.id === current,
        click: () => { config.save({ displayId: d.id }); fitOverlay(); rebuildTray(); },
      })),
    },
    { label: t.wander, type: 'checkbox', checked: cfg.wander, click: (item) => updateConfig({ wander: item.checked }) },
    { label: t.possess, type: 'checkbox', checked: cfg.possess, click: (item) => updateConfig({ possess: item.checked }) },
    {
      label: t.lang,
      submenu: [[t.auto, 'auto'], ...LANGS.map((lang) => [TRAY[lang].name, lang])].map(([label, lang]) => ({
        label, type: 'radio', checked: cfg.lang === lang, click: () => updateConfig({ lang }),
      })),
    },
    {
      label: t.startup,
      type: 'checkbox',
      checked: app.getLoginItemSettings(loginItemOptions()).openAtLogin,
      click: (item) => app.setLoginItemSettings({ ...loginItemOptions(), openAtLogin: item.checked }),
    },
    { type: 'separator' },
    hookState.installed
      ? { label: t.hooksOn, enabled: false }
      : { label: t.hooksOff, click: () => runHooks('install') },
    ...(hookState.installed ? [{ label: t.hooksRemove, click: () => runHooks('uninstall') }] : []),
    { type: 'separator' },
    { label: t.quit, click: () => app.quit() },
  ]);
  tray.setContextMenu(menu);
  trayMenu = menu;
}

// Run from a clone (`npm start`), electron.exe alone would open the default Electron app at login:
// it needs the project folder as argument.
function loginItemOptions() {
  return app.isPackaged ? {} : { path: process.execPath, args: [ROOT] };
}

// From the tray, she says how it went; from her welcome panel (quiet), the panel does.
function runHooks(action, { quiet = false } = {}) {
  let outcome;
  try {
    const result = action === 'install' ? hooks.install() : hooks.uninstall();
    outcome = { action, ok: true, file: result.file };
  } catch (err) {
    outcome = { action, ok: false, error: err.message };
  }
  if (!quiet) sendCommand('hooks', outcome);
  rebuildTray();
  return outcome;
}

function createTray() {
  const icon = nativeImage.createFromPath(path.join(ROOT, 'assets', 'icons', 'tray.png'));
  tray = new Tray(icon);
  tray.setToolTip('Capri');
  tray.on('click', () => sendCommand('status'));
  rebuildTray();
}

function registerIpc() {
  ipcMain.on('overlay:interactive', (_e, on) => {
    overlay?.setIgnoreMouseEvents(!on, { forward: true });
  });
  ipcMain.handle('overlay:cursor', () => {
    const p = screen.getCursorScreenPoint();
    const b = overlay.getBounds();
    return { x: p.x - b.x, y: p.y - b.y, inside: p.x >= b.x && p.y >= b.y && p.x < b.x + b.width && p.y < b.y + b.height };
  });
  ipcMain.handle('config:get', () => rendererConfig());
  ipcMain.handle('hooks:status', () => hooks.status());
  ipcMain.handle('config:set', (_e, patch) => updateConfig(patch));
  ipcMain.handle('demo:window', (_e, open) => demoWindow(open));
  // right-clicking her: the same menu as the tray icon (which Windows often hides behind the ^ by the clock)
  ipcMain.on('menu:open', () => trayMenu?.popup({ window: overlay }));
  ipcMain.on('media:control', (_e, action) => media?.control(String(action)));
  // her welcome panel's buttons
  ipcMain.handle('hooks:install', () => runHooks('install', { quiet: true }));
  ipcMain.handle('claude:found', () => fs.existsSync(path.dirname(hooks.status().file))); // Claude Code keeps its settings there
  ipcMain.on('claude:help', () => shell.openExternal(CLAUDE_CODE_HELP));
  ipcMain.handle('windows:get', () => lastWindows);
  // her guide: where her tray icon is (it lives in the taskbar, off the overlay, hence overlay
  // coordinates past its edge), and the corner by the clock in case Windows hid it behind the ^
  ipcMain.handle('guide:tray', () => {
    const o = overlay.getBounds();
    const d = targetDisplay().bounds;
    const b = tray?.getBounds();
    const icon = b && b.width > 0 ? { x: b.x - o.x, y: b.y - o.y, w: b.width, h: b.height } : null;
    const corner = { x: d.x + d.width - 150 - o.x, y: d.y + d.height - 44 - o.y, w: 140, h: 40 };
    return { icon, corner };
  });
  // her guide: Claude Code's folder (~/.claude) in Explorer, its settings file selected
  ipcMain.handle('guide:claudeFolder', () => {
    const file = hooks.status().file;
    const dir = path.dirname(file);
    if (!fs.existsSync(dir)) return { found: false, dir };
    if (fs.existsSync(file)) shell.showItemInFolder(file);
    else shell.openPath(dir);
    return { found: true, dir, file: fs.existsSync(file) };
  });
  ipcMain.handle('sounds:list', () => {
    try {
      return fs.readdirSync(userSoundsDir())
        .filter((f) => SOUND_EXT.test(f))
        .map((f) => ({ name: f.replace(SOUND_EXT, '').toLowerCase(), url: `capri://usersounds/${encodeURIComponent(f)}` }));
    } catch {
      return [];
    }
  });
}

// Only in --dev: lets scripts drive the overlay and grab frames of it (no desktop content, just our window).
const testWins = new Map(); // name -> test window

async function debugHandler(route, body) {
  if (!DEV) throw new Error('debug routes need --dev');
  if (route === 'command') {
    sendCommand(body.name, body);
    return { ok: true };
  }
  if (route === 'reload') {
    overlay.webContents.reloadIgnoringCache();
    return { ok: true };
  }
  if (route === 'testwin') {
    // plain windows to sit on, opened without stealing focus, by name (`id`, default "main");
    // each one opened goes in front of the others. { open: false } without an id closes them all.
    const id = body.id ?? 'main';
    if (!body.open && body.id === undefined) {
      for (const win of testWins.values()) win.destroy();
      testWins.clear();
      return { ok: true };
    }
    testWins.get(id)?.destroy();
    testWins.delete(id);
    if (body.open) {
      const b = overlay.getBounds();
      const win = new BrowserWindow({
        x: b.x + (body.x ?? 300), y: b.y + (body.y ?? 380), width: body.w ?? 720, height: body.h ?? 380,
        show: false, alwaysOnTop: true, title: `Capri test window ${id}`, backgroundColor: '#1b1726',
      });
      win.loadURL('data:text/html,<body style="background:%231b1726"></body>');
      win.showInactive();
      testWins.set(id, win);
    }
    return { ok: true };
  }
  if (route === 'movewin' && testWins.has(body.id ?? 'main')) {
    const win = testWins.get(body.id ?? 'main');
    const [x, y] = win.getPosition();
    win.setPosition(x + (body.dx || 0), y + (body.dy || 0));
    return { ok: true };
  }
  if (route === 'mouse') {
    // the pointer moving over the overlay (css px), and clicking if asked, without touching the real one
    const at = { x: Math.round(body.x), y: Math.round(body.y) };
    overlay.webContents.sendInputEvent({ type: 'mouseMove', ...at });
    if (body.click) {
      overlay.webContents.sendInputEvent({ type: 'mouseDown', button: 'left', clickCount: 1, ...at });
      overlay.webContents.sendInputEvent({ type: 'mouseUp', button: 'left', clickCount: 1, ...at });
    }
    return { ok: true };
  }
  if (route === 'capture') {
    const image = await overlay.webContents.capturePage();
    // installed, the app's own folder is read-only: its data folder instead
    const dir = path.join(app.isPackaged ? app.getPath('userData') : ROOT, 'captures');
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `${(body.name || 'frame').replace(/[^\w-]/g, '')}.png`);
    fs.writeFileSync(file, image.toPNG());
    return { ok: true, file };
  }
  throw new Error('unknown debug route');
}

function main() {
  if (!app.requestSingleInstanceLock()) {
    app.quit();
    return;
  }
  app.on('second-instance', () => sendCommand('status'));
  if (process.platform === 'win32') app.setAppUserModelId('capri.desktop');

  app.whenReady().then(() => {
    serveProtocol();
    registerIpc();
    registerChatIpc();
    registerQuickIpc();
    createOverlay();
    createTray();
    windowWatch = startWindowWatch({
      overlay,
      onUpdate: (data) => {
        lastWindows = data;
        overlay?.webContents.send('windows:update', data);
      },
    });
    createBridge({
      port: PORT,
      onEvent: (evt) => overlay?.webContents.send('claude:event', evt),
      onDebug: DEV ? debugHandler : null,
    });
    globalShortcut.register('Control+Alt+C', () => toggleVisible());
    globalShortcut.register('Control+Alt+V', openChat);
    globalShortcut.register('Control+Alt+Space', openQuick);
    globalShortcut.register('Control+Alt+T', translateClipboard);
    globalShortcut.register('Control+Alt+M', () => sendCommand('mediaCard'));
    if (config.load().music !== false) media = startMedia({ onUpdate: (track) => sendCommand('media', { track }) });
    screen.on('display-metrics-changed', fitOverlay);
    screen.on('display-added', () => { fitOverlay(); rebuildTray(); });
    screen.on('display-removed', () => { fitOverlay(); rebuildTray(); });
  });

  app.on('will-quit', () => {
    globalShortcut.unregisterAll();
    windowWatch?.stop();
    media?.stop();
  });
  app.on('window-all-closed', (e) => e.preventDefault());
}

main();
