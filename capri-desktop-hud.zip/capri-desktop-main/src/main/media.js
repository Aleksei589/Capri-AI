'use strict';

// What's playing on this PC (Spotify, a browser tab...) and the three buttons that control it.
// A small PowerShell script talks to the Windows media session; nothing here goes on the network.

const path = require('node:path');
const readline = require('node:readline');
const { spawn } = require('node:child_process');

const SCRIPT = path.join(__dirname, 'media.ps1').replace(`app.asar${path.sep}`, `app.asar.unpacked${path.sep}`);
const PS = ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', SCRIPT];
const ACTIONS = new Set(['toggle', 'next', 'prev']);

// onUpdate(track | null): { app, title, artist, playing, pos, dur } as it is now
function startMedia({ onUpdate }) {
  if (process.platform !== 'win32') return { stop() {}, control() {} };

  let child = null;
  let stopped = false;
  let restarts = 0;

  const start = () => {
    child = spawn('powershell.exe', [...PS, '-ParentPid', String(process.pid)], {
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    readline.createInterface({ input: child.stdout }).on('line', (line) => {
      try {
        const data = JSON.parse(line);
        onUpdate(data.none || !data.title ? null : data);
      } catch {
        // not one of ours
      }
    });
    child.stderr.on('data', (d) => console.error('[capri] media:', String(d).trim()));
    child.on('exit', () => {
      child = null;
      if (!stopped && restarts++ < 3) setTimeout(start, 3000);
    });
  };

  start();
  return {
    stop() {
      stopped = true;
      child?.kill();
    },
    control(action) {
      if (!ACTIONS.has(action)) return;
      spawn('powershell.exe', [...PS, '-Action', action], { windowsHide: true, stdio: 'ignore' });
    },
  };
}

module.exports = { startMedia };
