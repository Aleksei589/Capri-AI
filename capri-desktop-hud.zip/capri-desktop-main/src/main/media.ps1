# What's playing, from the Windows media session (Spotify, a browser tab, any player that shows up in
# the volume flyout). Prints one JSON line when the track or its state changes, and every few seconds
# to resync the position. With -Action toggle|next|prev it presses that button once and exits.
param([string]$ParentPid = '0', [string]$Action = '')

$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime

$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
})[0]

function Await($op, $type) {
  $task = $asTask.MakeGenericMethod($type).Invoke($null, @($op))
  [void]$task.Wait(5000)
  if ($task.IsCompleted) { $task.Result }
}

$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType = WindowsRuntime]
$manager = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
if (-not $manager) { [Console]::Error.WriteLine('no media session manager'); exit 1 }

# a playing session first (Spotify among them if it is), else Spotify, else whatever Windows calls current
function Get-Chosen {
  $all = @($manager.GetSessions())
  if ($all.Count -eq 0) { return $null }
  $playing = @($all | Where-Object { [string]$_.GetPlaybackInfo().PlaybackStatus -eq 'Playing' })
  $pool = if ($playing.Count -gt 0) { $playing } else { $all }
  $spotify = $pool | Where-Object { $_.SourceAppUserModelId -match 'Spotify' } | Select-Object -First 1
  if ($spotify) { return $spotify }
  if ($playing.Count -gt 0) { return $playing[0] }
  $current = $manager.GetCurrentSession()
  if ($current) { return $current }
  return $all[0]
}

if ($Action) {
  $s = Get-Chosen
  if ($s) {
    switch ($Action) {
      'toggle' { [void](Await ($s.TryTogglePlayPauseAsync()) ([bool])) }
      'next'   { [void](Await ($s.TrySkipNextAsync()) ([bool])) }
      'prev'   { [void](Await ($s.TrySkipPreviousAsync()) ([bool])) }
    }
  }
  exit 0
}

$last = ''
$tick = 0
while ($true) {
  if ($ParentPid -ne '0' -and -not (Get-Process -Id ([int]$ParentPid) -ErrorAction SilentlyContinue)) { break }
  $out = $null
  $s = Get-Chosen
  if ($s) {
    $props = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
    $id = [string]$s.SourceAppUserModelId
    $app = if ($id -match 'Spotify') { 'Spotify' } else { ($id -replace '\.exe$', '') -replace '^.*!', '' }
    $time = $s.GetTimelineProperties()
    $out = [ordered]@{
      app     = $app
      title   = [string]$props.Title
      artist  = [string]$props.Artist
      playing = ([string]$s.GetPlaybackInfo().PlaybackStatus -eq 'Playing')
      pos     = [int]$time.Position.TotalSeconds
      dur     = [int]$time.EndTime.TotalSeconds
    }
  }
  $key = if ($out) { "$($out.app)|$($out.title)|$($out.artist)|$($out.playing)" } else { 'none' }
  if ($key -ne $last -or ($tick % 5) -eq 0) {
    $json = if ($out) { $out | ConvertTo-Json -Compress } else { '{"none":true}' }
    [Console]::Out.WriteLine($json)
    [Console]::Out.Flush()
  }
  $last = $key
  $tick++
  Start-Sleep -Seconds 1
}
