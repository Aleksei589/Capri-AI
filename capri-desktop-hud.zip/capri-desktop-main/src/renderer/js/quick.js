// The quick bar: type (or speak) to Capri without opening the chat window.
// Her answer comes out on the desktop, in her speech panel, and the talk is kept in the same chat.

import { T } from './chat-i18n.js';
import { blobToWav } from './audio.js';

const $ = (id) => document.getElementById(id);
const FACES = {
  calm: 'face-calm.png', aside: 'face-aside.png', smug: 'face-smug.png', wide: 'face-wide.png',
  look: 'face-look.png', laugh: 'face-laugh.png', many: 'face-many.png', grin: 'capri-face.png',
};
const MAX_REC_S = 120;
const VOICE_NAME = 'voice-message.wav';

let t = T.en;
let working = false;
let rec = null;
let faceTimer = null;

function status(text, error = false) {
  $('status').textContent = text;
  $('status').classList.toggle('quick__status--error', error);
}

function fail(result) {
  return (t.errors[result.code] || t.errors.other).replace('{message}', result.message || '');
}

function face(name) {
  clearTimeout(faceTimer);
  $('face').src = `../../assets/capri/${FACES[name] || FACES.calm}`;
  if (name && name !== 'calm') faceTimer = setTimeout(() => face('calm'), 9000);
}

const clock = (ms) => {
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

function showRec(on) {
  $('rec').hidden = !on;
  $('text').hidden = on;
  if (!on) $('text').focus();
}

async function startRec() {
  if (rec || working) return;
  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch {
    status(t.errors.mic, true);
    return;
  }
  const recorder = new MediaRecorder(stream);
  const chunks = [];
  recorder.addEventListener('dataavailable', (e) => { if (e.data.size) chunks.push(e.data); });
  rec = { stream, recorder, chunks, started: Date.now(), timer: null };
  rec.timer = setInterval(() => {
    const ms = Date.now() - rec.started;
    $('recTime').textContent = clock(ms);
    if (ms >= MAX_REC_S * 1000) stopRec(true);
  }, 250);
  recorder.start(500);
  $('recTime').textContent = '0:00';
  status(t.recording);
  showRec(true);
}

async function stopRec(sendIt) {
  const r = rec;
  if (!r) return;
  rec = null;
  clearInterval(r.timer);
  const length = Date.now() - r.started;
  showRec(false);
  await new Promise((done) => {
    r.recorder.addEventListener('stop', done, { once: true });
    if (r.recorder.state === 'inactive') done();
    else r.recorder.stop();
  });
  r.stream.getTracks().forEach((tr) => tr.stop());
  status(t.quickHint);
  if (!sendIt || length < 600) return;
  try {
    const data = await blobToWav(new Blob(r.chunks, { type: r.recorder.mimeType }));
    await submit({ name: VOICE_NAME, mime: 'audio/wav', data });
  } catch (err) {
    console.error('[capri quick] recording failed', err);
    status(t.errors.recfail, true);
  }
}

async function submit(voice) {
  if (working) return;
  const text = $('text').value.trim();
  const files = voice ? [voice] : [];
  if (!text && !files.length) return;
  working = true;
  $('go').disabled = true;
  $('mic').disabled = true;
  $('text').disabled = true;
  status('…');
  const result = await window.quick.send({ text, files });
  working = false;
  $('go').disabled = false;
  $('mic').disabled = false;
  $('text').disabled = false;
  if (result.ok) {
    $('text').value = '';
    face(result.mood);
    status(t.quickHint);
  } else {
    status(fail(result), true);
  }
  $('text').focus();
}

async function boot() {
  const state = await window.quick.state();
  t = T[state.lang] || T.en;
  document.documentElement.lang = state.lang;
  $('text').placeholder = t.quickPlaceholder;
  $('go').textContent = t.send;
  $('mic').title = t.record;
  status(t.quickHint);

  $('form').addEventListener('submit', (e) => {
    e.preventDefault();
    if (rec) stopRec(true);
    else submit();
  });
  $('mic').addEventListener('click', () => (rec ? stopRec(true) : startRec()));
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (rec) stopRec(false);
    else window.quick.close();
  });
  window.addEventListener('blur', () => { if (rec) stopRec(false); }); // no recording in the background
  window.quick.onShow(() => {
    if (!working) {
      status(t.quickHint);
      face('calm');
    }
    $('text').focus();
    $('text').select();
  });
  $('text').focus();
}

boot().catch((err) => console.error('[capri quick] boot failed', err));
