// The portrait screen of the chat window (the "personal link" look): her face, a status tag that
// follows what she is doing, a glitch when it changes, and a zoom. chat.js drives it through window.hud.

const $ = (id) => document.getElementById(id);

const TAGS = {
  online: 'ONLINE', thinking: 'THINKING', receiving: 'RECEIVING', speaking: 'SPEAKING', input: 'TEXT INPUT',
};
const HINTS = {
  en: { thinking: 'Capri is replying…', receiving: 'Capri is replying…', speaking: 'Capri is speaking…' },
  ru: { thinking: 'Capri отвечает…', receiving: 'Capri отвечает…', speaking: 'Capri говорит…' },
  fr: { thinking: 'Capri répond…', receiving: 'Capri répond…', speaking: 'Capri parle…' },
  es: { thinking: 'Capri responde…', receiving: 'Capri responde…', speaking: 'Capri habla…' },
  pt: { thinking: 'Capri está respondendo…', receiving: 'Capri está respondendo…', speaking: 'Capri está falando…' },
};
// her close-ups, by mood
const CUTIN = {
  calm: 'cutin-look.png', look: 'cutin-look.png', aside: 'cutin-look.png', smug: 'cutin-grin.png',
  grin: 'cutin-grin.png', laugh: 'cutin-laugh.png', wide: 'cutin-eyes.png', many: 'cutin-many.png',
};
const reduced = matchMedia('(prefers-reduced-motion: reduce)');

let current = 'online';
let speakTimer = null;
let glitchTimer = null;
let zoom = 100;

function glitch() {
  if (reduced.matches) return;
  const screen = $('hudScreen');
  screen.classList.remove('is-glitching');
  void screen.offsetWidth; // restart the animation
  screen.classList.add('is-glitching');
  clearTimeout(glitchTimer);
  glitchTimer = setTimeout(() => screen.classList.remove('is-glitching'), 650);
}

function state(name) {
  if (name === current) return;
  current = name;
  const screen = $('hudScreen');
  screen.dataset.state = name;
  $('hudTag').textContent = `CAPRI // ${TAGS[name] || TAGS.online}`;
  const hints = HINTS[document.documentElement.lang] || HINTS.en;
  $('hintStatus').textContent = hints[name] || '';
  glitch();
}

function mood(name) {
  $('hudImg').src = `../../assets/capri/${CUTIN[name] || CUTIN.calm}`;
}

// Her answer arrives: a beat of "receiving", then she "speaks" for as long as it takes to read it.
function reply(text, moodName) {
  mood(moodName);
  state('receiving');
  clearTimeout(speakTimer);
  speakTimer = setTimeout(() => {
    state('speaking');
    speakTimer = setTimeout(() => state('online'), Math.min(9000, 1500 + String(text || '').length * 45));
  }, 700);
}

function setZoom(v) {
  zoom = Math.max(100, Math.min(300, v));
  $('hudImg').style.setProperty('--zoom', zoom / 100);
  $('zoomVal').textContent = `${zoom}%`;
}

$('zoomIn').addEventListener('click', () => setZoom(zoom + 20));
$('zoomOut').addEventListener('click', () => setZoom(zoom - 20));

window.hud = { state, mood, reply, get current() { return current; } };
