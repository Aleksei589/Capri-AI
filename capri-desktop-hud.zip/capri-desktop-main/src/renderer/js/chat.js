// The chat window: talks to Capri's Gemini brain through the preload bridge (window.chat).
// Everything from the model is put on screen as plain text, never as HTML.

import { blobToWav } from './audio.js';
import { T } from './chat-i18n.js';

const $ = (id) => document.getElementById(id);
const log = $('log');
const input = $('input');
const send = $('send');
const MAX_REC_S = 300;           // a voice message is at most 5 minutes
const VOICE_NAME = 'voice-message.wav';

let t = T.en;
let lang = 'en';
let working = false;
let hasKey = false;
let conv = { id: '', messages: [] };
let accept = { exts: [], maxFile: 13 * 1024 * 1024, maxFiles: 8 };
let pending = [];                // files chosen but not sent yet: { name, mime, data }
let rec = null;                  // the recording in progress
let urls = [];                   // object URLs of the messages on screen
let moodTimer = null;

// Her face in the title bar follows the mood of her last answer, then settles back.
const FACE_FILES = {
  calm: 'face-calm.png', aside: 'face-aside.png', smug: 'face-smug.png', wide: 'face-wide.png',
  look: 'face-look.png', laugh: 'face-laugh.png', many: 'face-many.png', grin: 'capri-face.png',
};
function mood(name) {
  const img = document.querySelector('.bar__face');
  clearTimeout(moodTimer);
  img.src = `../../assets/capri/${FACE_FILES[name] || FACE_FILES.calm}`;
  if (name && name !== 'calm') moodTimer = setTimeout(() => mood('calm'), 9000);
}

// ---------------------------------------------------------------- helpers

const extOf = (name) => (/\.[^.]+$/.exec(name) || [''])[0].toLowerCase();

function kindOf(name, mime) {
  const ext = extOf(name);
  if (/^image\//.test(mime) || ['.png', '.jpg', '.jpeg', '.webp', '.heic', '.heif'].includes(ext)) return 'image';
  if (/^audio\//.test(mime) || ['.wav', '.mp3', '.aiff', '.aif', '.aac', '.ogg', '.flac'].includes(ext)) return 'audio';
  return 'file';
}

function sizeText(n) {
  if (n >= 1048576) return `${(n / 1048576).toFixed(1)} MB`;
  return `${Math.max(1, Math.round(n / 1024))} KB`;
}

function blobUrl(bytes, mime) {
  const url = URL.createObjectURL(new Blob([bytes], { type: mime || 'application/octet-stream' }));
  urls.push(url);
  return url;
}

function revokeAll() {
  for (const u of urls) URL.revokeObjectURL(u);
  urls = [];
}

function titleOf(c) {
  if (!c.title) return t.untitled;
  return c.title === VOICE_NAME ? t.voice : c.title;
}

function fail(result) {
  const template = t.errors[result.code] || t.errors.other;
  return template.replace('{message}', result.message || '');
}

// ---------------------------------------------------------------- messages

function chip(name, size) {
  const el = document.createElement('span');
  el.className = 'chip';
  const n = document.createElement('span');
  n.className = 'chip__name';
  n.textContent = name;
  el.append(n);
  if (size) {
    const s = document.createElement('span');
    s.className = 'chip__size';
    s.textContent = sizeText(size);
    el.append(s);
  }
  return el;
}

// One attachment inside a message. `local` is its bytes when we still have them (just sent).
function attachmentNode(a, local) {
  const kind = a.kind === 'image' || a.kind === 'audio' ? a.kind : 'file';
  if (kind === 'file') return chip(a.name, a.size);

  const el = document.createElement(kind === 'image' ? 'img' : 'audio');
  if (kind === 'image') {
    el.className = 'msg__img';
    el.alt = a.name;
  } else {
    el.className = 'msg__audio';
    el.controls = true;
    el.preload = 'metadata';
  }
  const id = conv.id;
  const showChip = () => { if (el.isConnected) el.replaceWith(chip(a.name, a.size)); };
  el.addEventListener('error', showChip);
  (async () => {
    try {
      const bytes = local || (a.file ? (await window.chat.file(id, a.file)).bytes : null);
      if (!bytes) throw new Error('no bytes');
      el.src = blobUrl(bytes, a.mime);
    } catch {
      showChip();
    }
  })();
  if (kind === 'audio' && a.name !== VOICE_NAME) {
    const box = document.createElement('div');
    box.append(el);
    return box;
  }
  return el;
}

function add(kind, text, atts = [], locals = []) {
  const el = document.createElement('div');
  el.className = `msg msg--${kind}`;
  if (atts.length) {
    const box = document.createElement('div');
    box.className = 'msg__atts';
    atts.forEach((a, i) => box.append(attachmentNode(a, locals[i])));
    el.append(box);
  }
  if (text) {
    const p = document.createElement('div');
    p.textContent = text;
    el.append(p);
  }
  log.append(el);
  log.scrollTop = log.scrollHeight;
  return el;
}

function render() {
  revokeAll();
  log.replaceChildren();
  add('capri', t.hello);
  for (const m of conv.messages) add(m.role === 'user' ? 'user' : 'capri', m.text, m.attachments || []);
}

// ---------------------------------------------------------------- views

function view(name) {
  const setup = name === 'setup';
  const hist = name === 'history';
  $('setup').hidden = !setup;
  $('history').hidden = !hist;
  log.hidden = setup || hist;
  $('composer').hidden = setup || hist || Boolean(rec);
  $('tray').hidden = setup || hist || !pending.length;
  $('recbar').hidden = !rec;
  $('changeKey').hidden = setup;
  $('newChat').hidden = setup;
  $('historyBtn').hidden = setup;
  if (setup) $('keyInput').focus();
  else if (!hist) input.focus();
}

const chatView = () => view('chat');

function setWorking(on) {
  working = on;
  if (on) window.hud?.state('thinking');
  else if (window.hud?.current === 'thinking') window.hud.state('online');
  send.disabled = on;
  $('attach').disabled = on;
  $('mic').disabled = on;
  $('historyBtn').disabled = on;
  $('newChat').disabled = on;
}

function grow() {
  if (!working && window.hud && ['online', 'input'].includes(window.hud.current)) {
    window.hud.state(input.value ? 'input' : 'online');
  }
  input.style.height = 'auto';
  input.style.height = `${Math.min(input.scrollHeight, 140)}px`;
}

// ---------------------------------------------------------------- files waiting to be sent

function renderTray() {
  const tray = $('tray');
  tray.replaceChildren();
  pending.forEach((f, i) => {
    const el = chip(f.name, f.data.length);
    if (kindOf(f.name, f.mime) === 'image') {
      const img = document.createElement('img');
      img.className = 'chip__thumb';
      img.alt = '';
      img.addEventListener('error', () => img.remove());
      img.src = blobUrl(f.data, f.mime);
      el.prepend(img);
    }
    const x = document.createElement('button');
    x.type = 'button';
    x.className = 'chip__x';
    x.textContent = '×';
    x.title = t.remove;
    x.addEventListener('click', () => {
      pending.splice(i, 1);
      renderTray();
    });
    el.append(x);
    tray.append(el);
  });
  tray.hidden = !pending.length || !$('setup').hidden || !$('history').hidden;
}

async function addFiles(files) {
  for (const f of files) {
    if (pending.length >= accept.maxFiles) {
      add('error', t.errors.toomany);
      break;
    }
    const ext = extOf(f.name);
    const textual = /^text\//.test(f.type);
    if (!accept.exts.includes(ext) && !textual) {
      add('error', fail({ code: 'unsupported', message: f.name }));
      continue;
    }
    if (f.size > accept.maxFile) {
      add('error', fail({ code: 'toolarge', message: f.name }));
      continue;
    }
    pending.push({ name: f.name || 'file', mime: f.type, data: new Uint8Array(await f.arrayBuffer()) });
  }
  renderTray();
  input.focus();
}

// ---------------------------------------------------------------- sending

async function submit(voice) {
  const text = input.value.trim();
  const files = voice ? [...pending, voice] : [...pending];
  if ((!text && !files.length) || working) return;
  setWorking(true);
  const sent = pending;
  pending = [];
  renderTray();
  input.value = '';
  grow();

  const atts = files.map((f) => ({ name: f.name, kind: kindOf(f.name, f.mime), mime: f.mime, size: f.data.length }));
  const mine = add('user', text, atts, files.map((f) => f.data));
  const wait = add('wait', '…');
  wait.classList.add('msg--capri');

  const result = await window.chat.send({ text, files });
  wait.remove();
  if (result.ok) {
    add('capri', result.reply);
    mood(result.mood);
    window.hud?.reply(result.reply, result.mood);
  } else {
    // nothing was kept: give the message back so it can be sent again
    mine.remove();
    input.value = text;
    grow();
    pending = voice ? [...sent, voice] : sent;
    renderTray();
    add('error', fail(result));
    if (result.code === 'nokey' || result.code === 'badkey') view('setup');
  }
  setWorking(false);
  input.focus();
}

// ---------------------------------------------------------------- voice messages

const clock = (ms) => {
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

async function startRecording() {
  if (rec || working) return;
  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch {
    add('error', t.errors.mic);
    return;
  }
  const recorder = new MediaRecorder(stream);
  const chunks = [];
  recorder.addEventListener('dataavailable', (e) => { if (e.data.size) chunks.push(e.data); });
  rec = { stream, recorder, chunks, started: Date.now(), timer: null };
  rec.timer = setInterval(() => {
    const ms = Date.now() - rec.started;
    $('recTime').textContent = clock(ms);
    if (ms >= MAX_REC_S * 1000) stopRecording(true);
  }, 250);
  recorder.start(500);
  $('recTime').textContent = '0:00';
  view('chat');
}

// Stops the recording; with send=true it goes to Capri as a voice message.
async function stopRecording(sendIt) {
  const r = rec;
  if (!r) return;
  rec = null;
  clearInterval(r.timer);
  const length = Date.now() - r.started;
  view('chat');
  await new Promise((done) => {
    r.recorder.addEventListener('stop', done, { once: true });
    if (r.recorder.state === 'inactive') done();
    else r.recorder.stop();
  });
  r.stream.getTracks().forEach((tr) => tr.stop());
  if (!sendIt || length < 600) return;
  try {
    const data = await blobToWav(new Blob(r.chunks, { type: r.recorder.mimeType }));
    await submit({ name: VOICE_NAME, mime: 'audio/wav', data });
  } catch (err) {
    console.error('[capri chat] recording failed', err);
    add('error', t.errors.recfail);
  }
}

// ---------------------------------------------------------------- past chats

function openChat(c) {
  conv = c;
  mood('calm');
  render();
  chatView();
}

async function showHistory() {
  const result = await window.chat.list();
  const list = result.ok ? result.list : [];
  const ul = $('historyList');
  ul.replaceChildren();
  $('historyEmpty').hidden = list.length > 0;
  for (const c of list) {
    const li = document.createElement('li');
    li.className = `hist__row${c.id === conv.id ? ' hist__row--current' : ''}`;

    const open = document.createElement('button');
    open.type = 'button';
    open.className = 'hist__open';
    const title = document.createElement('span');
    title.className = 'hist__title';
    title.textContent = titleOf(c);
    const meta = document.createElement('span');
    meta.className = 'hist__meta';
    meta.textContent = `${new Date(c.updated).toLocaleString(lang, { dateStyle: 'medium', timeStyle: 'short' })} · ${c.count}`;
    open.append(title, meta);
    open.addEventListener('click', async () => {
      const r = await window.chat.open(c.id);
      if (r.ok) openChat(r.conv);
    });

    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'hist__del';
    del.textContent = t.deleteChat;
    let armed = null;
    del.addEventListener('click', async () => {
      if (!armed) {
        del.textContent = t.confirmDelete;
        del.classList.add('hist__del--sure');
        armed = setTimeout(() => {
          armed = null;
          del.textContent = t.deleteChat;
          del.classList.remove('hist__del--sure');
        }, 3000);
        return;
      }
      clearTimeout(armed);
      const r = await window.chat.remove(c.id);
      if (r.ok) {
        conv = r.conv;
        render();
        showHistory();
      }
    });

    li.append(open, del);
    ul.append(li);
  }
  view('history');
}

// ---------------------------------------------------------------- boot

async function boot() {
  const state = await window.chat.state();
  lang = T[state.lang] ? state.lang : 'en';
  t = T[lang];
  document.documentElement.lang = lang;
  accept = state.accept || accept;
  conv = state.conv;

  input.placeholder = t.placeholder;
  send.textContent = t.send;
  $('newChat').textContent = t.newChat;
  $('changeKey').textContent = t.changeKey;
  $('historyBtn').textContent = t.history;
  $('historyTitle').textContent = t.historyTitle;
  $('historyEmpty').textContent = t.historyEmpty;
  $('attach').title = t.attach;
  $('mic').title = t.record;
  $('recLabel').textContent = t.recording;
  $('recCancel').textContent = t.cancel;
  $('recSend').textContent = t.send;
  $('setupTitle').textContent = t.setupTitle;
  $('setupText').textContent = t.setupText;
  $('getKey').textContent = t.getKey;
  $('keyInput').placeholder = t.keyPlaceholder;
  $('keySave').textContent = t.save;
  document.body.dataset.drop = t.drop;
  $('fileInput').accept = accept.exts.join(',');

  hasKey = state.hasKey;
  render();
  view(hasKey ? 'chat' : 'setup');

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (rec) stopRecording(false);
    else if (hasKey && (!$('setup').hidden || !$('history').hidden)) chatView();
  });

  $('composer').addEventListener('submit', (e) => {
    e.preventDefault();
    submit();
  });
  input.addEventListener('input', grow);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      submit();
    }
  });
  input.addEventListener('paste', (e) => {
    const files = [...(e.clipboardData?.files || [])];
    if (!files.length) return;
    e.preventDefault();
    addFiles(files);
  });

  $('attach').addEventListener('click', () => $('fileInput').click());
  $('fileInput').addEventListener('change', async (e) => {
    const files = [...e.target.files];
    e.target.value = '';
    await addFiles(files);
  });
  let drag = 0;
  const hasFiles = (e) => [...(e.dataTransfer?.types || [])].includes('Files');
  document.addEventListener('dragenter', (e) => { if (hasFiles(e)) { drag++; document.body.classList.add('dragging'); } });
  document.addEventListener('dragleave', (e) => { if (hasFiles(e) && --drag <= 0) { drag = 0; document.body.classList.remove('dragging'); } });
  document.addEventListener('dragover', (e) => { if (hasFiles(e)) e.preventDefault(); });
  document.addEventListener('drop', (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    drag = 0;
    document.body.classList.remove('dragging');
    if (hasKey && !working && !rec && $('setup').hidden && $('history').hidden) addFiles([...e.dataTransfer.files]);
  });

  window.chat.onChanged(async () => { // she was talked to from the quick bar
    if (working || rec) return;
    const fresh = await window.chat.state();
    if (!fresh?.conv) return;
    conv = fresh.conv;
    render();
  });

  $('mic').addEventListener('click', startRecording);
  $('recCancel').addEventListener('click', () => stopRecording(false));
  $('recSend').addEventListener('click', () => stopRecording(true));

  $('newChat').addEventListener('click', async () => {
    const r = await window.chat.create();
    if (r.ok) {
      pending = [];
      renderTray();
      openChat(r.conv);
    }
  });
  $('historyBtn').addEventListener('click', () => {
    if ($('history').hidden) showHistory();
    else chatView();
  });
  $('changeKey').addEventListener('click', () => view('setup'));
  $('getKey').addEventListener('click', () => window.chat.keyPage());

  $('keyForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const error = $('setupError');
    const save = $('keySave');
    error.hidden = true;
    save.disabled = true;
    save.textContent = t.checking;
    const result = await window.chat.setKey($('keyInput').value);
    save.disabled = false;
    save.textContent = t.save;
    if (!result.ok) {
      error.textContent = fail(result);
      error.hidden = false;
      return;
    }
    $('keyInput').value = '';
    hasKey = true;
    chatView();
  });
}

boot().catch((err) => console.error('[capri chat] boot failed', err));
