import { Capri } from './capri.js';
import { FxLayer } from './fx.js';
import { Chip, Mask } from './chip.js';
import { Panel, FACES } from './panel.js';
import { Voice } from './voice.js';
import { Brain } from './brain.js';
import { Guide } from './guide.js';
import { LINES } from './lines.js';
import { pick, fmt } from './util.js';

const host = window.host;

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

// close-ups of her for the cut-ins, frames of the show (tools/build-cutins.py)
const CUTINS = ['grin', 'laugh', 'eyes', 'many', 'look'];

async function boot() {
  const [config, image, intro, ...cutins] = await Promise.all([
    host.getConfig(),
    loadImage('../../assets/capri/capri-full.png'),
    loadImage('../../assets/capri/intro-face.webp').catch(() => null), // her intro, frames of the show
    ...CUTINS.map((name) => loadImage(`../../assets/capri/cutin-${name}.png`)),
    document.fonts.load('600 16px "Chakra Petch"'),
    document.fonts.load('400 11px "JetBrains Mono"'),
  ]);
  document.documentElement.lang = config.lang;

  const fx = new FxLayer(document.getElementById('fx'), {
    cutins: Object.fromEntries(CUTINS.map((name, i) => [name, cutins[i]])),
    intro,
  });
  fx.resize(innerWidth, innerHeight);
  const chip = new Chip(document.getElementById('chip'));
  chip.place(innerWidth, innerHeight);
  const mask = new Mask(document.getElementById('mask'));

  const voice = new Voice();
  voice.configure(config);
  host.listSounds().then((list) => list.length && voice.loadCustom(list));

  const panel = new Panel({
    panel: document.getElementById('panel'),
    ticker: document.getElementById('ticker'),
    labels: LINES[config.lang] || LINES.fr,
  });

  const capri = new Capri({
    root: document.getElementById('capri'),
    canvas: document.getElementById('sprite'),
    image,
    fx,
    voice,
  });
  capri.wander = config.wander;
  capri.possessWindows = config.possess;
  capri.setScale(config.scale);

  const brain = new Brain({ capri, panel, voice, host, lang: config.lang });

  // Click-through everywhere except on her body, the panel and her biochip.
  let interactive = false;
  let mouse = null;
  const setInteractive = (on) => {
    if (on === interactive) return;
    interactive = on;
    host.setInteractive(on);
  };
  const onChip = () => Boolean(chip.visible && mouse && chip.contains(mouse.x, mouse.y, 0));
  const refreshHit = () => {
    if (capri.dragging) return setInteractive(true);
    if (!mouse) return setInteractive(false);
    const r = panel.rect();
    const onPanel = r && mouse.x >= r.left && mouse.x <= r.right && mouse.y >= r.top && mouse.y <= r.bottom;
    document.body.style.cursor = onChip() ? 'pointer' : '';
    return setInteractive(Boolean(onPanel || capri.hit(mouse.x, mouse.y) || onChip()));
  };
  // Her biochip: her eyes on it follow the pointer over it, and she comes out when you click it
  // (only then, so the pointer passing through that corner doesn't call her back).
  // Her mask, asleep: the pointer coming over it stirs her, and a moment of that wakes her up.
  let wakeTimer = 0;
  const comeOut = () => {
    if (capri.stowed) host.setConfig({ visible: true }); // the tray and Ctrl+Alt+C follow
    capri.unstow();
  };
  const hoverChip = () => {
    chip.pointer = chip.visible && mouse && chip.contains(mouse.x, mouse.y) ? mouse : null;
    const near = mask.visible && mouse && mask.contains(mouse.x, mouse.y, 30);
    mask.pointer = near ? mouse : null;
    if (!near) {
      clearTimeout(wakeTimer);
      wakeTimer = 0;
    } else if (!wakeTimer) {
      wakeTimer = setTimeout(() => {
        wakeTimer = 0;
        if (capri.dormant) capri.wake();
      }, 400);
    }
  };
  window.addEventListener('mousemove', (e) => {
    mouse = { x: e.clientX, y: e.clientY };
    refreshHit();
    hoverChip();
  });
  document.addEventListener('mouseleave', () => {
    mouse = null;
    refreshHit();
    hoverChip();
  });
  window.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    if (chip.visible && chip.contains(e.clientX, e.clientY, 0)) host.openMenu();
  });
  window.addEventListener('click', (e) => {
    if (chip.visible && chip.contains(e.clientX, e.clientY, 0)) comeOut();
  });

  // wiring
  capri.onMove = (head) => {
    // pointing at something: the panel goes on her other side, so it doesn't cover it
    panel.setAnchor({ ...head, lean: capri.pointing ? -capri.pointing.dir : 0 }, capri.view);
    // she may have moved out from under a still pointer: never leave a dead click zone behind
    refreshHit();
  };
  capri.onTeleport = (phase) => (phase === 'start' ? panel.suspend() : panel.resume());
  capri.chipAt = () => chip.center();
  capri.onStow = () => {
    chip.setMode(capri.mode);
    chip.show();
  };
  capri.onUnstow = () => chip.hide();
  capri.onDoze = (phase, face) => {
    if (phase === 'start') {
      mask.place(face.x, face.y, capri.scale * 1.1);
      mask.show();
    } else if (phase === 'waking') {
      mask.wake();
    } else {
      mask.hide();
    }
  };
  capri.onMode = (mode, prev) => chip.setMode(mode, prev);
  // now and then she says something about the satellite: while she looks at it, or once
  // the red light has gone up (never during, nothing should cover that)
  capri.onGaze = (when) => {
    const lines = when === 'end' ? brain.t.uplink : brain.t.gaze;
    if (!panel.visible && Math.random() < (when === 'end' ? 0.6 : 0.4)) panel.say({ kind: 'info', line: pick(lines), hold: 3800 });
  };
  // her head, for the quick bar to sit above (none when she's put away: it then goes low in the middle)
  const quickSpot = () => {
    if (capri.stowed) return null;
    const h = capri.head();
    return { x: h.x, y: h.top ?? h.y - 120 };
  };
  let lastClick = 0;
  capri.onClick = () => {
    const now = performance.now();
    if (now - lastClick < 400) { // a double click: talk to her
      lastClick = 0;
      host.openQuick(quickSpot());
      return;
    }
    lastClick = now;
    if (panel.visible) panel.hide();
    else brain.status();
  };
  panel.onChar = (kind) => voice.play('blip', { mood: kind });
  panel.onTalk = (talking) => talking && capri.perform('talk');
  capri.onMenu = () => host.openMenu();

  // Her guide (guide.js): her welcome on first launch, and "How does it work?" in her menu,
  // where she takes you to things and points at them.
  const guide = new Guide({ capri, panel, voice, host, brain });
  // The player card's buttons ride on the panel's buttons: "media:toggle", "media:next", "media:prev".
  const guideAction = panel.onAction;
  panel.onAction = (id) => {
    if (String(id).startsWith('media:')) host.mediaControl(String(id).slice(6));
    else guideAction?.(id);
  };
  // What's playing on this PC: she reacts when a new track starts, and Ctrl+Alt+M shows the player.
  let track = null;
  let musicKey = '';
  let musicSeen = false;
  let musicAt = 0;
  const playerMsg = () => {
    const m = brain.t.player;
    if (!track) return { kind: 'info', badge: 'MEDIA', face: 'look', line: m.none, hold: 5000 };
    return {
      kind: 'info', player: true, badge: String(track.app || 'MEDIA').toUpperCase(),
      tag: track.playing ? m.now : m.paused, face: track.playing ? 'smug' : 'calm',
      line: track.title, quote: track.artist,
      actions: [
        { id: 'media:prev', label: '⏮' },
        { id: 'media:toggle', label: track.playing ? '⏸' : '▶', primary: true },
        { id: 'media:next', label: '⏭' },
      ],
      hold: 15000,
    };
  };
  // the first Claude Code event that ever reaches her: so you know it worked
  brain.linked = config.linked;
  brain.onLinked = () => {
    host.setConfig({ linked: true, welcomed: true });
    voice.play('hello');
    capri.perform('hop');
    panel.say({ kind: 'done', badge: 'LINK', line: brain.t.welcome.linked, hold: 6000 });
  };

  // The demo's second half, after its fake Claude session: everything she does on her own, one
  // after the other, a line before each.
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const until = async (done, max = 15000) => {
    for (const t0 = Date.now(); !done() && Date.now() - t0 < max;) await wait(100);
  };
  const free = () => !capri.busy && !capri.act && capri.stance !== 'fall';
  brain.onShowcase = async () => {
    const t = brain.t.showcase;
    const caption = (line) => panel.say({ kind: 'info', line, hold: 2200 });
    capri.nextMove = capri.nextGaze = performance.now() + 120000; // nothing of her own in between
    if (capri.stowed) await capri.unstow();
    if (capri.dormant) capri.wake();
    await until(free);
    panel.hide();

    caption(t.minds);
    await wait(1000);
    await capri.perform('split');
    await wait(900);

    caption(t.zap);
    await wait(1000);
    const h = capri.head();
    capri.zap(h.x + capri.towardCenter() * 280, h.y - 170);
    await wait(1800);

    panel.hide();
    if (capri.gaze({ big: true })) await until(() => !capri.sky);
    await wait(2500);

    // a little terminal opens for her to take over, and closes under her once she's done with it
    if (capri.possessWindows && (await host.demoWindow(true))) {
      const top = () => capri.windows.wins.find((w) => capri.canSit(w)); // it opens on top of everything
      await until(top, 4000);
      const win = top();
      const seat = win && { win, dx: win.w * 0.4 };
      if (seat) {
        panel.hide();
        await capri.sitOn(seat);
        await until(free);
        caption(t.possess);
        await wait(1400);
        panel.hide();
        await capri.possess();
        await wait(1800);
      }
      host.demoWindow(false);
      await wait(400);
      await until(free); // she may have fallen off it
      await wait(900);
    }

    caption(t.sleep);
    await wait(1400);
    panel.hide();
    capri.setMode('sleep');
    await wait(2500); // dozing off
    await capri.doze();
    await wait(4500);
    capri.wake();
    await until(free);
    await wait(1200);

    caption(t.chip);
    await wait(1600);
    panel.hide();
    await capri.stow();
    await wait(3500);
    await capri.unstow();
    await wait(600);
    panel.say({ kind: 'info', line: t.end, hold: 5000 });
  };

  host.onClaudeEvent((evt) => brain.handle(evt));
  host.onWindows((data) => {
    capri.setWindows(data);
    brain.onWindows(data);
  });
  // the windows as they are now: the watcher only speaks again when something changes
  host.windowsNow().then((data) => data && capri.setWindows(data));

  host.onResize(({ width, height }) => {
    fx.resize(width, height);
    chip.place(width, height);
    capri.setView(width, height);
  });
  window.addEventListener('resize', () => {
    fx.resize(innerWidth, innerHeight);
    chip.place(innerWidth, innerHeight);
    capri.setView(innerWidth, innerHeight);
  });

  host.onConfig((cfg) => {
    voice.configure(cfg);
    capri.wander = cfg.wander;
    capri.possessWindows = cfg.possess;
    if (cfg.scale !== capri.scale) capri.setScale(cfg.scale);
    if (cfg.lang !== brain.lang) {
      brain.lang = cfg.lang;
      panel.labels = LINES[cfg.lang] || LINES.fr;
      document.documentElement.lang = cfg.lang;
    }
  });

  // What the chat can make her do (the names are the ones listed in src/main/chat.js, ACTIONS).
  // "hide" and "show" are settings, so main handles those.
  const toward = () => capri.towardCenter();
  const CHAT_ACTS = {
    teleport: () => capri.teleport(capri.spot('random')),
    sit: () => {
      const seat = capri.pickSeat();
      return seat ? capri.sitOn(seat) : capri.teleport(capri.spot('random'));
    },
    peek: () => capri.peek(),
    possess: async () => {
      if (!(await capri.possess())) capri.perform('curious', toward());
    },
    gaze: () => capri.gaze({ big: false }),
    spin: () => capri.perform('spin', toward()),
    hop: () => capri.perform('hop', toward()),
    look: () => capri.perform('look', toward()),
    curious: () => capri.perform('curious', toward()),
    split: () => capri.perform('split', toward()),
    celebrate: () => capri.celebrate(),
    hurt: () => capri.hurt(),
    alarm: () => capri.perform('alarm', toward()),
    zap: () => {
      const h = capri.head();
      capri.zap(h.x + toward() * 280, h.y - 170);
    },
    summon: async () => {
      const cursor = await host.cursor().catch(() => null);
      if (cursor?.inside) await capri.summon(cursor);
      else capri.perform('hop', toward());
    },
    sleep: () => capri.setMode('sleep'),
    wake: () => capri.wake(),
  };

  function chatAct(name) {
    const act = CHAT_ACTS[name];
    if (!act) return;
    if (name !== 'sleep') capri.wake();
    Promise.resolve()
      .then(act)
      .catch((err) => console.error('[capri] chat action failed:', name, err));
  }

  host.onCommand(async (cmd) => {
    const t = brain.t;
    switch (cmd.name) {
      case 'teleport':
        capri.teleport(capri.spot('random'));
        break;
      case 'status':
        brain.status();
        break;
      case 'welcome': // "How does it work?" in her menu
        guide.menu();
        break;
      case 'fakeClaude': { // --dev: the topmost window (the test window) is where a prompt was typed, and you're elsewhere
        const win = capri.windows.wins[0];
        if (win) {
          brain.sessions.set('dev', { id: 'dev', project: 'dev', taskStart: Date.now(), count: 0, files: new Set(), log: [], working: true, waiting: false, window: win.id, seen: Date.now() });
          capri.windows = { ...capri.windows, fg: -1 };
        }
        break;
      }
      case 'guide': // --dev: one topic of her guide (welcome, menu, connect, icon, claude, folder)
        if (cmd.topic === 'welcome') guide.welcome();
        else if (cmd.topic === 'menu') guide.menu();
        else if (typeof guide[cmd.topic] === 'function') guide.scene(() => guide[cmd.topic]());
        break;
      case 'stow': // Ctrl+Alt+C: into her biochip, or back out
        if (cmd.on) capri.stow();
        else capri.unstow();
        break;
      case 'satellite': // the whole sequence, on demand (tray)
        if (capri.stowed) {
          host.setConfig({ visible: true });
          await capri.unstow();
        }
        capri.wake();
        if (capri.stance === 'peek') await capri.unpeek();
        if (!capri.gaze({ big: true })) setTimeout(() => capri.gaze({ big: true }), 1500);
        break;
      case 'quickAt': // hotkey / tray: where is she, for the quick bar
        host.openQuick(quickSpot());
        break;
      case 'media': { // the track changed, or started/stopped playing
        track = cmd.track || null;
        if (panel.current?.player && panel.visible) panel.say(playerMsg());
        const key = track ? `${track.app}|${track.title}|${track.artist}` : '';
        if (!musicSeen) { // what was already playing when she woke up isn't news
          musicSeen = true;
          musicKey = key;
          break;
        }
        if (track?.playing && key !== musicKey && !capri.stowed && performance.now() - musicAt > 20000) {
          musicAt = performance.now();
          panel.say({ kind: 'info', badge: brain.t.musicBadge, face: 'smug', line: pick(brain.t.music), quote: `${track.title} — ${track.artist}`, hold: 7000 });
        }
        if (key) musicKey = key;
        break;
      }
      case 'mediaCard': // Ctrl+Alt+M
        if (!capri.stowed) panel.say(playerMsg());
        break;
      case 'translate': { // Ctrl+Alt+T: the clipboard, translated
        if (capri.stowed) break;
        const m = brain.t.translate;
        if (panel.current?.translation) panel.hide(); // a new one replaces the last
        if (cmd.busy) panel.say({ kind: 'info', translation: true, badge: m.badge, face: 'look', line: m.busy, hold: 40000 });
        else if (cmd.ok) panel.say({ kind: 'info', translation: true, badge: m.badge, face: 'smug', line: pick(m.done), quote: cmd.from ? `${cmd.from} → ${cmd.to}` : cmd.to, reply: cmd.text, hold: null });
        else panel.say({ kind: 'info', translation: true, badge: m.badge, face: 'wide', line: cmd.error === 'empty' ? m.empty : m.error, hold: 9000 });
        break;
      }
      case 'chatSend': // you wrote to her in the chat window: she notices
        if (capri.stowed) break;
        capri.wake();
        capri.twitch();
        voice.play('tick');
        break;
      case 'chat': { // her answer from the chat window: the face she makes, what she does, and what she says
        if (capri.stowed) break; // put away: she stays quiet (the answer is in the chat window)
        const text = String(cmd.text || '');
        const face = FACES[cmd.mood] ? cmd.mood : 'smug';
        if (cmd.say) {
          const long = text.length > 160;
          panel.say({ kind: 'info', badge: 'CHAT', face, line: long ? '▸' : text, reply: long ? text : '', hold: long ? null : Math.min(20000, Math.max(9000, text.length * 80)) });
        }
        chatAct(cmd.action);
        break;
      }
      case 'hooks':
        if (cmd.ok) panel.say({ kind: 'info', line: cmd.action === 'install' ? t.hooksOk : t.hooksRemoved, hold: 6000 });
        else panel.say({ kind: 'error', line: fmt(t.hooksFail, { error: cmd.error }), hold: 9000 });
        break;
      // --dev helpers
      case 'intro': // her intro again, as when she starts (still: as with Windows' animations off)
        panel.hide();
        await capri.intro(capri.spot('post'), cmd.still ? { still: true } : {});
        break;
      case 'pose':
        capri.debug = cmd.params || null;
        if (cmd.still) capri.nextMove = capri.nextGaze = Infinity; // no wandering off mid-test
        if (cmd.hush) {
          panel.setTicker(null);
          panel.hide();
        }
        if (cmd.scale) capri.setScale(cmd.scale);
        if (cmd.stance) capri.setStance(cmd.stance, cmd);
        if (cmd.at) capri.pos = cmd.at;
        if (cmd.facing) capri.facing = cmd.facing;
        capri.drawFrame();
        break;
      case 'config': // a setting, as if changed from her menu
        host.setConfig(cmd.patch || {});
        break;
      case 'focus': // as if window `fg` had come to the front
        capri.windows = { ...capri.windows, fg: cmd.fg };
        brain.onWindows(capri.windows);
        break;
      case 'freeze':
        capri.hidden = Boolean(cmd.on);
        break;
      case 'act':
        // behaviours by method name (gaze, celebrate, hurt, shed, peek, fall, wanderStep...) or acts by name
        if (cmd.act === 'sit') {
          // pile: n-th window she could sit on from the top of the pile (0: the --dev test window
          // opened last), instead of the usual choice
          const top = cmd.pile !== undefined && capri.windows.wins.filter((w) => capri.canSit(w))[cmd.pile];
          const seat = top ? { win: top, dx: top.w * 0.4 } : capri.pickSeat();
          if (seat) capri.sitOn(seat);
        } else if (typeof capri[cmd.act] === 'function') capri[cmd.act](...(cmd.args || []));
        else capri.perform(cmd.act, cmd.dir || 0);
        break;
      default:
        break;
    }
  });

  // entrance: her face big in the corner says hi, then she dives down to her spot
  // (put away last time: she starts in her biochip)
  if (config.visible === false) capri.stowNow();
  else if (intro) await capri.intro(capri.spot('post'));
  else await capri.materialize(capri.spot('post'));
  const hooks = await host.hooksStatus();
  if (!config.welcomed || !hooks.installed) guide.welcome();
  else panel.say({ kind: 'info', line: pick(brain.t.online), hold: 4000 });
}

boot().catch((err) => {
  console.error('[capri] boot failed', err);
});
