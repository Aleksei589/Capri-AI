'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('quick', {
  state: () => ipcRenderer.invoke('quick:state'),
  send: (payload) => ipcRenderer.invoke('quick:send', {
    text: String(payload?.text || ''),
    files: (payload?.files || []).map((f) => ({ name: String(f.name), mime: String(f.mime || ''), data: f.data })),
  }),
  close: () => ipcRenderer.send('quick:close'),
  onShow: (fn) => ipcRenderer.on('quick:show', () => fn()),
});
